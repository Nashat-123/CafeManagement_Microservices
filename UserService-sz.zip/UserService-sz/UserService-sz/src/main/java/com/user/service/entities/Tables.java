package com.user.service.entities;

public class Tables {

	 private String tableId;
	    private String userId;
	    private String menuId;
	    private  int tablerow;
	    private  String tableNo;
	   
}
